import IEventData from './IEventData';
export default class Event {
    constructor(eventData: IEventData);
}
