import IEventData, { IPlayerData } from './IEventData';

export default class Event {
  // TODO: Fill this in.
  /* tslint:disable:no-empty */
  constructor(eventData: IEventData) { }
}
