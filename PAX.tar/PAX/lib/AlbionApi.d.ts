import IBattleData from './Battle/IBattleData';
/**
 * Options that may be passed to a request, and used to form
 *   a query string.
 */
export interface IRequestOptions {
    /**
     * The amount of battles to load. Max is 51.
     */
    limit?: number;
    /**
     * The offset from the newest kill.
     */
    offset?: number;
    /**
     * How to sort the results.
     */
    sort?: string;
}
/**
 * Get a single Battle by battleId
 */
export declare function getBattle(battleId: string): Promise<IBattleData>;
/**
 * Get an array of Battles.
 */
export declare function getBattles(options: IRequestOptions): Promise<IBattleData[]>;
/**
 * Get a single Battle by eventId
 */
export declare function getEvent(eventId: string): Promise<any>;
/**
 * Get an array of Kills.
 */
export declare function getEvents(options: IRequestOptions): Promise<any[]>;
/**
 * Get Albion Online status information
 */
export declare function serverStatusRequest(): Promise<any>;
