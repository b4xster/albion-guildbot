import Alliance from './Alliance';
import Faction from './Faction';
import Guild from './Guild';
import IBattleData, { IPlayerData } from './IBattleData';
/**
 * A {@link Battle} is an immutable object that abstracts relevant details about
 *   an AO battle from raw battle data received from the AO API.
 */
export default class Battle {
    /**
     * A Map of {@link Alliance}s by name.
     */
    alliances: Map<string, Alliance>;
    /**
     * The time the battle ended.
     */
    endTime: string;
    /**
     * An array of all {@link Faction}s involved in the fight, sorted by rank.
     */
    rankedFactions: Faction[];
    /**
     * A Map of {@link Guild}s by name.
     */
    guilds: Map<string, Guild>;
    /**
     * The ID of this {@link Battle}.
     */
    id: number;
    /**
     * Whether this Battle describes a 5v5.
     */
    is5v5: Boolean;
    /**
     * An array of all {@link IPlayerData}s.
     */
    players: IPlayerData[];
    /**
     * The title of this battle.
     */
    title: string;
    /**
     * The total fame this battle.
     */
    totalFame: number;
    /**
     * The total number of kills this battle.
     */
    totalKills: number;
    constructor(battleData: IBattleData);
}
