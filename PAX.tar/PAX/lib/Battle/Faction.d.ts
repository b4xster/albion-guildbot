import IBattleData, { IPlayerData } from './IBattleData';
/**
 * The type of grouping a {@link Faction} represents.
 */
export declare enum FactionType {
    Alliance = "alliance",
    Guild = "guild",
    Unguilded = "unguilded"
}
/**
 * A {@link FactionLike} object has the properties
 *   necessary to construct a {@link Faction}.
 */
export interface IFactionLike {
    deaths: number;
    factionType: FactionType;
    killFame: number;
    kills: number;
    name: string;
    players: IPlayerData[];
}
/**
 * A {@link Faction} is an immutable object that represents the faction a
 *   player or group of players belongs to. A faction can represent an
 *   {@link Alliance}, {@link Guild} or 'Unguilded'; whichever is the
 *   highest level of organization the player belongs to. This is primarily
 *   used for being able to associate all players with a group.
 */
export default class Faction implements IFactionLike {
    /**
     * Construct a {@link Faction} by extracting and grouping all of the
     *   unguilded players in the passed {@link IBattleData}.
     */
    static fromUnguilded(battleData: IBattleData): Faction;
    deaths: number;
    factionType: FactionType;
    killFame: number;
    kills: number;
    name: string;
    players: IPlayerData[];
    constructor(factionLike: IFactionLike);
}
