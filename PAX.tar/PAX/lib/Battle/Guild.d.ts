import { FactionType, IFactionLike } from './Faction';
import IBattleData, { IGuildData, IPlayerData } from './IBattleData';
/**
 * An {@link Guild} is an immutable object that abstracts relevant details about
 *   a group of {@link Player}s present in the same AO {@link Battle} from raw
 *   battle data received from the AO API.
 */
export default class Guild implements IFactionLike {
    alliance: string;
    deaths: number;
    factionType: FactionType;
    killFame: number;
    kills: number;
    name: string;
    players: IPlayerData[];
    constructor(guildData: IGuildData, battleData: IBattleData);
}
