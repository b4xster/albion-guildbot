
module.exports = {
  discord: {
    token: 'NTIwOTY5MzA2ODI2MjExMzUw.DvUNAw.ca7sr5BX2kjEocVkclf40Cm1UK4',
    feedChannelId: '518802576637034496',
    killChannelId: '523254626418688004',
    statusChannelId: '518802576637034496',
  },
  guild: {
    guilds: ['Bursztynowy Kartel', 'Corona Regni Poloniae', 'Moon Guards', 'KFC', 'Kaczuszki','We are Tox1c'],
    alliance: 'PAX'
  },
  battle: {
    minPlayers: 5,
    minRelevantPlayers: 5
  },
  kill: {
    minFame: 1000
  }
};


